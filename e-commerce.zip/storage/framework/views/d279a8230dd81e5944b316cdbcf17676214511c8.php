<?php if(sizeof($errors)): ?>
	<div class="alert alert-danger">
		<ol>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($_error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ol>
	</div>
<?php endif; ?><?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/partials/_errors.blade.php ENDPATH**/ ?>