

<?php $__env->startSection('content'); ?>
<div class="_page _loginPage" style="background-image: url(<?php echo e(asset('resources/img/CV-Login.jpg')); ?>); background-size: cover; -webkit-background-size: cover;">
	<div class="container">
		<div class="_auth" style="margin: 50px auto;">
			<?php echo $__env->make('partials._info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('partials._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<div class="row">
				<div class="col-md-6">
					<form class="form-horizontal _auth__form" method="POST" action="<?php echo e(route('login')); ?>">
						<div class="_auth__form__group">
							<input type="text" class="form-control" name="user_name" value="<?php echo e(old('user_name')); ?>" placeholder="User Name" required autofocus />
                           
							<input type="password" class="form-control" name="password" placeholder="Password" required />
							<input type="password" class="form-control hidden" name="password2" placeholder="" />
						</div>
						<div class="_auth__form__footer">
							<a class="_auth__link" href="<?php echo e(route('password.request')); ?>">
								Forgot Your Password?
							</a>
							
							<div>
								<span class="_switchLabel">Remember Me</span>
								<div class="_switch">
									<input id="remember" type="checkbox" class="_switch__input" name="remember" checked />
									<label for="remember" class="_switch__label">
										
										<span class="_switch__circle"></span>
										
									</label>
								</div>
							</div>
						</div>
						<div class="form-footer">
							<button type="submit" class="btn btn-block btn-primary">
								Login
							</button>
							<?php echo e(csrf_field()); ?>

						</div>
					</form>
				</div>
				<div class="col-md-6">
					<div class="_auth__info">
						<h3 class="_auth__headline">Become a customer</h3>
						<div class="form-footer">
							<a class="btn btn-block btn-primary" href="<?php echo e(route('register')); ?>">Haven't Registered Yet?</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/auth/login.blade.php ENDPATH**/ ?>