<?php if($msg = session('msg')): ?>
	<div class="alert alert-<?php echo e(session('ok') ? 'success' : 'danger'); ?>">
		<strong><?php echo e($msg); ?></strong>
	</div>
<?php endif; ?><?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/partials/_info.blade.php ENDPATH**/ ?>