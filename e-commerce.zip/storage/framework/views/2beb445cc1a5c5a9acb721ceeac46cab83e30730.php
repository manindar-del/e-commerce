

<?php $__env->startSection('content'); ?>



<section class="booking">
    <div class="container">

      eeeeeeeeeeeeee

        

</section>

<div class="_loader" id="loader" style="background-image: url(<?php echo e(asset('images/loader.jpg')); ?>)">
    <img class="_loader__img" src="<?php echo e(asset('images/loader.gif')); ?>" alt="" />
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footer-bottom'); ?>
    <script src="<?php echo e(asset('assets/js/moment.js')); ?>"></script>

    


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/agent/home/index.blade.php ENDPATH**/ ?>