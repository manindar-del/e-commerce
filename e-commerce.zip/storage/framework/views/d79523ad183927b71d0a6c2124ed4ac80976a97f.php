



<?php $__env->startSection('content'); ?>
<div class="_page">
    <div class="container">

        <form class="form-horizontal _signup" method="POST" action="<?php echo e(route('register')); ?>">

            <?php echo e(csrf_field()); ?>


        

            <h1 class="_signup__headline">Customer Registration</h1>

            <div class="row">

                <div class="col-sm-6">

                    

                    <div class="form-group<?php echo e($errors->has('user_name') ? ' has-error' : ''); ?>">
                        <label for="user_name" class="col-md-4 control-label">User Name*</label>
                        <div class="col-md-8">
                            <input id="user_name" type="text" class="form-control" name="user_name" value="<?php echo e(old('user_name')); ?>" required autofocus />
                            <?php if($errors->has('user_name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('user_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-4 control-label">Name*</label>
                        <div class="col-md-8">
                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required />
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('company_name') ? ' has-error' : ''); ?>">
                        <label for="company_name" class="col-md-4 control-label">Company Name</label>
                        <div class="col-md-8">
                            <input id="company_name" type="text" class="form-control" name="company_name" value="<?php echo e(old('company_name')); ?>" />

                            <?php if($errors->has('company_name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('company_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-md-4 control-label">E-Mail Address*</label>
                        <div class="col-md-8">
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required />

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('email_confirmation') ? ' has-error' : ''); ?>">
                        <label for="email_confirmation" class="col-md-4 control-label"> Confirm E-mail Address*</label>
                        <div class="col-md-8">
                            <input id="email_confirmation" type="email" class="form-control" name="email_confirmation" value="<?php echo e(old('email_confirmation')); ?>" required />

                            <?php if($errors->has('email_confirmation')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-4 control-label">Choose your Password*</label>
                        <div class="col-md-8">
                            <input id="password" type="password" class="form-control" name="password" required />

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                        <label for="password_confirmation" class="col-md-4 control-label">Confirm Your Password*</label>
                        <div class="col-md-8">
                            <input id="password_confirmation" type="password" class="form-control" name="password_confirmation" required />

                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

            </div>

            <div class="_signup__footer">
                <button type="submit" class="btn btn-primary">
                    Register
                </button>
                <?php echo e(csrf_field()); ?>

            </div>

        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/auth/register.blade.php ENDPATH**/ ?>