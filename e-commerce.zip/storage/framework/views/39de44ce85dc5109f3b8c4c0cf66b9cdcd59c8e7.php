<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title ?? config('app.name')); ?></title>
    <?php if(!empty($seo_meta)): ?>
        <meta name="description" content="<?php echo e($seo_meta); ?>" />
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('header-top'); ?>
    <?php echo $__env->yieldPushContent('header'); ?>
    <?php echo $__env->yieldPushContent('header-bottom'); ?>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700|Roboto+Condensed:300,400,700|Poppins:200,300,400,500,700" rel="stylesheet" />

</head>
<body>

    <div id="app">
        <?php echo $__env->yieldContent('header'); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->yieldContent('footer'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('footer-top'); ?>

    <?php echo $__env->yieldPushContent('footer'); ?>


    <?php echo $__env->yieldPushContent('footer-bottom'); ?>


</body>
</html>
<?php /**PATH D:\xamppp\htdocs\e-commerce\resources\views/layouts/app.blade.php ENDPATH**/ ?>